# YOLO_DATA > 2024-01-27 11:06pm
https://universe.roboflow.com/dog-bite-detection/yolo_data-k63eg

Provided by a Roboflow user
License: CC BY 4.0

